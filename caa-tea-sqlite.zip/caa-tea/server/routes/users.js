import { Router } from 'express';
import db from '../db/sqlite.js';
import { requireAuth, requireAdult } from '../middleware/auth.js';

const router = Router();

router.get('/children', requireAuth, requireAdult, (req, res) => {
  const rows = db.prepare(
    `SELECT u.id,u.name,u.avatar_color,u.created_at FROM users u
     JOIN adult_child_links l ON l.child_id=u.id
     WHERE l.adult_id=? ORDER BY u.name`
  ).all(req.user.id);
  res.json(rows);
});

router.get('/all-children', (_req, res) => {
  const rows = db.prepare(`SELECT id,name,avatar_color FROM users WHERE role='child' ORDER BY name`).all();
  res.json(rows);
});

export default router;
