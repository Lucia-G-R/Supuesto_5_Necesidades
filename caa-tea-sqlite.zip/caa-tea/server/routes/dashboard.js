import { Router } from 'express';
import db from '../db/sqlite.js';
import { requireAuth, requireAdult } from '../middleware/auth.js';

const router = Router();

router.get('/:childId', requireAuth, requireAdult, (req, res) => {
  const { childId } = req.params;
  const weeks = parseInt(req.query.weeks)||8;
  const days  = parseInt(req.query.days)||30;

  // LMF semanal
  const lmfSeries = db.prepare(
    `SELECT strftime('%Y-%W', created_at) as week,
            ROUND(AVG(phrase_length),2) as lmf,
            COUNT(*) as total_phrases
     FROM generated_phrases
     WHERE user_id=? AND created_at >= datetime('now','-'||?||' days')
     GROUP BY week ORDER BY week`
  ).all(childId, weeks * 7);

  // Diversidad léxica (aproximada con count de frases únicas)
  const diversity = db.prepare(
    `SELECT COUNT(*) as count FROM generated_phrases
     WHERE user_id=? AND created_at >= datetime('now','-'||?||' days')`
  ).get(childId, days);

  // Frecuencia uso
  const frequency = db.prepare(
    `SELECT strftime('%Y-%W', created_at) as week,
            COUNT(DISTINCT date(created_at)) as active_days
     FROM usage_events
     WHERE user_id=? AND created_at >= datetime('now','-'||?||' days')
     GROUP BY week ORDER BY week`
  ).all(childId, weeks * 7);

  // Autonomía emocional
  const emotStats = db.prepare(
    `SELECT COUNT(*) as total_logs,
            SUM(CASE WHEN strategy_chosen IS NOT NULL THEN 1 ELSE 0 END) as autonomous_logs
     FROM emotional_logs
     WHERE user_id=? AND created_at >= datetime('now','-'||?||' days')`
  ).get(childId, days);

  const emotionalAutonomy = {
    ...emotStats,
    autonomy_rate: emotStats.total_logs > 0
      ? Math.round((emotStats.autonomous_logs / emotStats.total_logs) * 1000) / 10
      : 0,
  };

  // Distribución emociones
  const emotionDistribution = db.prepare(
    `SELECT emotion, COUNT(*) as count FROM emotional_logs
     WHERE user_id=? AND created_at >= datetime('now','-'||?||' days')
     GROUP BY emotion ORDER BY count DESC`
  ).all(childId, days);

  res.json({ lmfSeries, diversity: { count: diversity.count, periodDays: days }, frequency, emotionalAutonomy, emotionDistribution });
});

export default router;
