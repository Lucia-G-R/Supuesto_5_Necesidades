import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';
import bcrypt from 'bcrypt';
import { randomUUID } from 'crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH   = join(__dirname, '..', '..', 'caa_tea.db');
const SCHEMA    = join(__dirname, '..', '..', 'sql', '001_schema_sqlite.sql');

// Abrir (o crear) la base de datos
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Crear tablas si no existen
const schema = readFileSync(SCHEMA, 'utf8');
db.exec(schema);

// Seed inicial si la tabla está vacía
const userCount = db.prepare('SELECT COUNT(*) as n FROM users').get();
if (userCount.n === 0) {
  const pinHash = bcrypt.hashSync('1234', 10);
  const adultId = randomUUID();
  const childId = randomUUID();

  db.prepare(`INSERT INTO users (id,name,role,pin_hash,avatar_color) VALUES (?,?,?,?,?)`)
    .run(adultId, 'María (mamá)', 'adult', pinHash, '#534AB7');

  db.prepare(`INSERT INTO users (id,name,role,avatar_color) VALUES (?,?,?,?)`)
    .run(childId, 'Mateo', 'child', '#1D9E75');

  db.prepare(`INSERT INTO adult_child_links (adult_id,child_id) VALUES (?,?)`)
    .run(adultId, childId);

  const scheduleId = randomUUID();
  db.prepare(`INSERT INTO schedules (id,child_id,date,slot_now,slot_next,slot_later) VALUES (?,?,date('now'),?,?,?)`)
    .run(
      scheduleId, childId,
      JSON.stringify({pictoId:2510, label:'Desayunar', imageUrl:'https://static.arasaac.org/pictograms/2510/2510_300.png', completed:false}),
      JSON.stringify({pictoId:6386, label:'Colegio',   imageUrl:'https://static.arasaac.org/pictograms/6386/6386_300.png', completed:false}),
      JSON.stringify({pictoId:3196, label:'Jugar',     imageUrl:'https://static.arasaac.org/pictograms/3196/3196_300.png', completed:false})
    );

  console.log('✅ Base de datos creada con datos demo');
  console.log('   Adulto:', adultId, '(PIN: 1234)');
  console.log('   Niño:  ', childId);
}

export default db;
export { randomUUID as uuid };
